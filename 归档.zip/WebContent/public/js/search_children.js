var _base = 'http://qzone.qq.com/gy/404/';
document.write('<script type="text/javascript" src="' + _base
		+ 'data.js" charset="utf-8"></script>');
document.write('<script type="text/javascript" src="public/js/page.js" charset="utf-8"></script>');/* |xGv00|bb048611f4d0bb34934fd40353d94edf */